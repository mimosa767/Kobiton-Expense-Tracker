import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider, useAuth } from "@/src/context/AuthContext";
import { ExpenseProvider } from "@/src/context/ExpenseContext";
import { LocationProvider } from "@/src/context/LocationContext";
import { kobitonSDK } from "@/src/services/kobitonSDK";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

const PUBLIC_ROUTES = new Set(['index', 'login', '+not-found']);

function RootLayoutNav() {
  const { session, isLoading } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (isLoading) return;
    const currentRoute = segments[0] ?? 'index';
    const isPublic = PUBLIC_ROUTES.has(currentRoute);
    if (!session && !isPublic) {
      router.replace('/login');
    }
  }, [session, isLoading, segments]);

  useEffect(() => {
    kobitonSDK.logEvent('App launched', 'info', { platform: require('react-native').Platform.OS });
  }, []);

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="login" />
      <Stack.Screen name="expenses" />
      <Stack.Screen name="add-expense" />
      <Stack.Screen name="expense/[id]" />
      <Stack.Screen name="debug" />
      <Stack.Screen name="location-mock" />
      <Stack.Screen name="media-gallery" />
      <Stack.Screen name="audio-capture" />
      <Stack.Screen name="system-metrics" />
      <Stack.Screen name="kobiton-sdk" />
      <Stack.Screen name="guide" />
      <Stack.Screen name="crash-app" />
      <Stack.Screen
        name="camera"
        options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom' }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AuthProvider>
                <LocationProvider>
                  <ExpenseProvider>
                    <RootLayoutNav />
                  </ExpenseProvider>
                </LocationProvider>
              </AuthProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
