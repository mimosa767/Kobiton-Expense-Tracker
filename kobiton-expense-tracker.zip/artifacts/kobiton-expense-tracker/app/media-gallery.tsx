import React, { useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { useExpenses } from '@/src/context/ExpenseContext';
import { Colors, Radius, Shadow, Spacing, Typography } from '@/src/constants/theme';

type Tab = 'gallery' | 'qr';

const { width: SW } = Dimensions.get('window');
const THUMB = (SW - Spacing.md * 2 - Spacing.sm * 2) / 3;

export default function MediaGalleryScreen() {
  const insets = useSafeAreaInsets();
  const { expenses } = useExpenses();
  const [tab, setTab] = useState<Tab>('gallery');
  const [scannedResult, setScannedResult] = useState<{ type: string; data: string } | null>(null);
  const [scanning, setScanning] = useState(true);
  const [pickedImages, setPickedImages] = useState<string[]>([]);
  const [permission, requestPermission] = useCameraPermissions();
  const lastScan = useRef(0);

  const receiptImages = expenses
    .filter((e) => e.attachmentUri)
    .map((e) => ({ uri: e.attachmentUri!, head: e.head }));

  const allImages = [
    ...receiptImages,
    ...pickedImages.map((uri) => ({ uri, head: 'Imported' })),
  ];

  async function handlePickImage() {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      quality: 0.8,
    });
    if (!res.canceled) {
      setPickedImages((prev) => [
        ...prev,
        ...res.assets.map((a) => a.uri).filter((u) => !prev.includes(u)),
      ]);
    }
  }

  function handleBarcodeScanned({ type, data }: { type: string; data: string }) {
    const now = Date.now();
    if (now - lastScan.current < 2000) return;
    lastScan.current = now;
    setScannedResult({ type, data });
    setScanning(false);
  }

  function handleRescan() {
    setScannedResult(null);
    setScanning(true);
    lastScan.current = 0;
  }

  function renderGallery() {
    return (
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[styles.galleryContent, { paddingBottom: insets.bottom + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Kobiton info card */}
        <View style={styles.infoCard}>
          <View style={styles.infoCardHeader}>
            <Feather name="image" size={15} color={Colors.primary} />
            <Text style={styles.infoCardTitle}>Image Injection Demo</Text>
          </View>
          <Text style={styles.infoCardText}>
            Use Kobiton's Image Injection feature to push a local image directly into the device's camera stream. Select any image below, then trigger the camera on device — Kobiton will replace the live feed with your chosen image.
          </Text>
        </View>

        <View style={styles.galleryHeader}>
          <Text style={styles.sectionTitle}>RECEIPT IMAGES & IMPORTS</Text>
          <TouchableOpacity style={styles.importBtn} onPress={handlePickImage} testID="pick-image">
            <Feather name="plus" size={14} color={Colors.primary} />
            <Text style={styles.importBtnText}>Import</Text>
          </TouchableOpacity>
        </View>

        {allImages.length === 0 ? (
          <View style={styles.emptyBox}>
            <Feather name="image" size={36} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>No images yet</Text>
            <Text style={styles.emptySubtitle}>
              Add expenses with receipts, or tap Import to select images from your library.
            </Text>
          </View>
        ) : (
          <View style={styles.thumbGrid}>
            {allImages.map((img, i) => (
              <View key={`${img.uri}-${i}`} style={styles.thumbWrapper}>
                <Image source={{ uri: img.uri }} style={styles.thumb} resizeMode="cover" />
                <View style={styles.thumbLabel}>
                  <Text style={styles.thumbLabelText} numberOfLines={1}>{img.head}</Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    );
  }

  function renderQR() {
    if (Platform.OS === 'web') {
      return (
        <View style={styles.webFallback}>
          <Feather name="camera-off" size={48} color={Colors.textMuted} />
          <Text style={styles.webFallbackTitle}>Camera not available on web</Text>
          <Text style={styles.webFallbackText}>
            The QR code scanner requires a native iOS or Android device. On Kobiton, use Image Injection to push a QR code image into the camera stream and watch it scan automatically.
          </Text>
          <View style={styles.infoCard}>
            <View style={styles.infoCardHeader}>
              <Feather name="zap" size={15} color={Colors.primary} />
              <Text style={styles.infoCardTitle}>How Image Injection Works</Text>
            </View>
            <Text style={styles.infoCardText}>
              1. Open a session on a Kobiton real device.{'\n'}
              2. Upload a QR code image via the Image Injection panel.{'\n'}
              3. Navigate to this screen — the camera will detect and decode the injected QR code just as if you held a physical code up to the lens.
            </Text>
          </View>
        </View>
      );
    }

    if (!permission) return null;

    if (!permission.granted) {
      return (
        <View style={styles.permBox}>
          <Feather name="camera-off" size={36} color={Colors.textMuted} />
          <Text style={styles.permTitle}>Camera permission needed</Text>
          <TouchableOpacity style={styles.permBtn} onPress={requestPermission}>
            <Text style={styles.permBtnText}>Grant Camera Access</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <View style={{ flex: 1 }}>
        {scanning ? (
          <View style={{ flex: 1, position: 'relative' }}>
            <CameraView
              style={{ flex: 1 }}
              facing="back"
              onBarcodeScanned={handleBarcodeScanned}
              barcodeScannerSettings={{ barcodeTypes: ['qr', 'ean13', 'code128', 'pdf417'] }}
            />
            {/* Viewfinder overlay */}
            <View style={styles.scanOverlay} pointerEvents="none">
              <View style={styles.scanFrame}>
                <View style={[styles.corner, styles.cornerTL]} />
                <View style={[styles.corner, styles.cornerTR]} />
                <View style={[styles.corner, styles.cornerBL]} />
                <View style={[styles.corner, styles.cornerBR]} />
              </View>
              <Text style={styles.scanHint}>Point camera at a QR or barcode</Text>
            </View>
          </View>
        ) : (
          <ScrollView
            contentContainerStyle={[styles.resultContent, { paddingBottom: insets.bottom + 24 }]}
          >
            <View style={styles.resultCard}>
              <View style={styles.resultIconRow}>
                <View style={styles.resultIconBg}>
                  <Feather name="check-circle" size={28} color={Colors.success} />
                </View>
              </View>
              <Text style={styles.resultTitle}>Scanned Successfully</Text>
              <Text style={styles.resultTypeLabel}>TYPE</Text>
              <Text style={styles.resultType}>{scannedResult?.type?.toUpperCase() ?? '—'}</Text>
              <Text style={styles.resultDataLabel}>DATA</Text>
              <View style={styles.resultDataBox}>
                <Text style={styles.resultData} selectable>{scannedResult?.data ?? ''}</Text>
              </View>
              <TouchableOpacity style={styles.rescanBtn} onPress={handleRescan} testID="rescan-btn">
                <Feather name="refresh-cw" size={16} color={Colors.white} />
                <Text style={styles.rescanBtnText}>Scan Again</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.infoCard}>
              <View style={styles.infoCardHeader}>
                <Feather name="zap" size={15} color={Colors.primary} />
                <Text style={styles.infoCardTitle}>Image Injection Demo</Text>
              </View>
              <Text style={styles.infoCardText}>
                This scan was triggered by a real or injected camera image. On Kobiton, you can inject a QR code image into the camera stream to automate scanning flows in your test scripts.
              </Text>
            </View>
          </ScrollView>
        )}
      </View>
    );
  }

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} testID="topbar-back-media-gallery">
          <Feather name="arrow-left" size={22} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Media Gallery</Text>
        <View style={{ width: 22 }} />
      </View>

      {/* Tabs */}
      <View style={styles.tabBar}>
        {(['gallery', 'qr'] as Tab[]).map((t) => (
          <TouchableOpacity
            key={t}
            style={[styles.tabBtn, tab === t && styles.tabBtnActive]}
            onPress={() => setTab(t)}
            testID={`tab-${t}`}
          >
            <Feather
              name={t === 'gallery' ? 'image' : 'maximize'}
              size={15}
              color={tab === t ? Colors.primary : Colors.textSecondary}
            />
            <Text style={[styles.tabLabel, tab === t && styles.tabLabelActive]}>
              {t === 'gallery' ? 'Gallery' : 'QR Scanner'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {tab === 'gallery' ? renderGallery() : renderQR()}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.surface },
  header: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: 14,
  },
  headerTitle: {
    fontSize: Typography.sizeLg,
    fontFamily: Typography.fontSemiBold,
    color: Colors.white,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 13,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabBtnActive: {
    borderBottomColor: Colors.primary,
  },
  tabLabel: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontMedium,
    color: Colors.textSecondary,
  },
  tabLabelActive: {
    color: Colors.primary,
    fontFamily: Typography.fontSemiBold,
  },
  galleryContent: { padding: Spacing.md, gap: Spacing.md },
  galleryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  sectionTitle: {
    fontSize: 11,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textMuted,
    letterSpacing: 1.2,
  },
  importBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.white,
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  importBtnText: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontMedium,
    color: Colors.primary,
  },
  thumbGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  thumbWrapper: {
    width: THUMB,
    height: THUMB,
    borderRadius: Radius.md,
    overflow: 'hidden',
    ...Shadow.card,
  },
  thumb: { width: '100%', height: '100%' },
  thumbLabel: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  thumbLabelText: {
    fontSize: 10,
    fontFamily: Typography.fontMedium,
    color: Colors.white,
  },
  emptyBox: {
    alignItems: 'center',
    gap: 10,
    paddingVertical: 48,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: Typography.sizeLg,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textSecondary,
  },
  emptySubtitle: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontRegular,
    color: Colors.textMuted,
    textAlign: 'center',
    lineHeight: 18,
  },
  infoCard: {
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    gap: 8,
    ...Shadow.card,
    borderLeftWidth: 3,
    borderLeftColor: Colors.primary,
  },
  infoCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  infoCardTitle: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontSemiBold,
    color: Colors.primary,
  },
  infoCardText: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontRegular,
    color: Colors.textSecondary,
    lineHeight: 19,
  },
  webFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  webFallbackTitle: {
    fontSize: Typography.sizeLg,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  webFallbackText: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontRegular,
    color: Colors.textMuted,
    textAlign: 'center',
    lineHeight: 19,
  },
  permBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.md,
    padding: Spacing.lg,
  },
  permTitle: {
    fontSize: Typography.sizeLg,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  permBtn: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.md,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  permBtnText: {
    fontSize: Typography.sizeMd,
    fontFamily: Typography.fontSemiBold,
    color: Colors.white,
  },
  scanOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
  },
  scanFrame: {
    width: 220,
    height: 220,
    position: 'relative',
  },
  corner: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderColor: Colors.white,
  },
  cornerTL: { top: 0, left: 0, borderTopWidth: 3, borderLeftWidth: 3, borderTopLeftRadius: 6 },
  cornerTR: { top: 0, right: 0, borderTopWidth: 3, borderRightWidth: 3, borderTopRightRadius: 6 },
  cornerBL: { bottom: 0, left: 0, borderBottomWidth: 3, borderLeftWidth: 3, borderBottomLeftRadius: 6 },
  cornerBR: { bottom: 0, right: 0, borderBottomWidth: 3, borderRightWidth: 3, borderBottomRightRadius: 6 },
  scanHint: {
    color: Colors.white,
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontMedium,
    backgroundColor: 'rgba(0,0,0,0.55)',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: Radius.full,
    overflow: 'hidden',
  },
  resultContent: { padding: Spacing.md, gap: Spacing.md },
  resultCard: {
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    gap: 8,
    ...Shadow.card,
  },
  resultIconRow: { marginBottom: 4 },
  resultIconBg: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.successLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultTitle: {
    fontSize: Typography.sizeXl,
    fontFamily: Typography.fontBold,
    color: Colors.textPrimary,
  },
  resultTypeLabel: {
    fontSize: 10,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textMuted,
    letterSpacing: 1,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  resultType: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontMedium,
    color: Colors.textSecondary,
    alignSelf: 'flex-start',
  },
  resultDataLabel: {
    fontSize: 10,
    fontFamily: Typography.fontSemiBold,
    color: Colors.textMuted,
    letterSpacing: 1,
    alignSelf: 'flex-start',
    marginTop: 4,
  },
  resultDataBox: {
    width: '100%',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.sm,
  },
  resultData: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontRegular,
    color: Colors.textPrimary,
    lineHeight: 18,
  },
  rescanBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    borderRadius: Radius.md,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 4,
    alignSelf: 'stretch',
    justifyContent: 'center',
  },
  rescanBtnText: {
    fontSize: Typography.sizeSm,
    fontFamily: Typography.fontSemiBold,
    color: Colors.white,
  },
});
